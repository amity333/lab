package com.cg.mps.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.cg.mps.dto.Customer;
import com.cg.mps.util.DBUtil;

public class MobileDaoImpl implements MobileDao {
	Connection con = null;
	Statement st = null;
	ResultSet rs = null;
	PreparedStatement pst = null;

	@Override
	public int addCust(Customer cust) throws ClassNotFoundException, IOException, SQLException {
		java.sql.Date sqlDate = MyStringDateUtil.fromLocalToSqlDate(cust.getDate());
		con = DBUtil.getCon();
		pst = con.prepareStatement(QueryMapper.MOB_INSERT_QRY);
		pst.setString(1, cust.getCustName());
		pst.setString(2, cust.getMailId());
		pst.setLong(3, cust.getPhoneNo());
		pst.setDate(4, sqlDate);
		pst.setInt(5, cust.getMobileId());
		int insertInc = pst.executeUpdate();

		return insertInc;
	}

	@Override
	public boolean Availability(int mobileId) throws ClassNotFoundException, IOException, SQLException {
		con = DBUtil.getCon();
		pst = con.prepareStatement(QueryMapper.MOB_AVAIL);
		rs = pst.executeQuery();
		int quantity = rs.getInt("quantity");
		if (quantity == 0) {
			return false;
		}
		return true;
	}

	@Override
	public int updateQuantity(int MobileId) throws ClassNotFoundException, IOException, SQLException {
		con = DBUtil.getCon();
		pst = con.prepareStatement(QueryMapper.MOB_UPDATE);
		pst.setInt(1, MobileId);
		pst.setInt(2, MobileId);
		int UpdateInc = pst.executeUpdate();
		return UpdateInc;
	}

	@Override
	public int deleteMobileEmtries(int MobileId) throws ClassNotFoundException, IOException, SQLException {
		con = DBUtil.getCon();
		pst = con.prepareStatement(QueryMapper.MOB_DEL_QRY);
		pst.setInt(1, MobileId);
		int DeleteCount = pst.executeUpdate();
		return DeleteCount;
	}

	@Override
	public ArrayList<Customer> fetchAll() throws ClassNotFoundException, IOException, SQLException {
		con = DBUtil.getCon();
		pst = con.prepareStatement(QueryMapper.MOB_SELECTALL);
		rs = pst.executeQuery();
		ArrayList<Customer> list = new ArrayList<Customer>();
		while (rs.next()) {
			Customer c1 = null;
			c1 = new Customer(rs.getInt("mobileid"), rs.getString("name"), rs.getFloat("price"), rs.getInt("quantity"));
			list.add(c1);
		}
		return list;
	}

	@Override
	public ArrayList<Customer> fetchByRange(float sRange, float eRange)
			throws ClassNotFoundException, IOException, SQLException {
		con = DBUtil.getCon();
		pst = con.prepareStatement(QueryMapper.MOB_SEL_BYRANGE);
		pst.setFloat(1, sRange);
		pst.setFloat(2, eRange);
		rs = pst.executeQuery();
		ArrayList<Customer> list = new ArrayList<Customer>();
		while (rs.next()) {
			Customer c1 = null;
			c1 = new Customer(rs.getInt("mobileid"), rs.getString("name"), rs.getFloat("price"), rs.getInt("quantity"));
			list.add(c1);
		}
		return list;
	}
}
