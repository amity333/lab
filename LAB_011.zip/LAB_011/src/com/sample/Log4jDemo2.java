package com.sample;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

public class Log4jDemo2 {
	static Logger log = null;

	public static void main(String args[]) {
		for (int i = 1; i < 5000; i++) {
			log = Logger.getLogger(Log4jDemo2.class);
			PropertyConfigurator.configure("log4j2.properties");
			System.out.println("Counter = " + i);
			log.debug("This is my debug message. Counter = " + i);
			log.info("This is my info message. Counter = " + i);
			log.warn("This is my warn message. Counter = " + i);
			log.error("This is my error message. Counter = " + i);
			log.fatal("This is my fatal message. Counter = " + i);
		}
	}
}
