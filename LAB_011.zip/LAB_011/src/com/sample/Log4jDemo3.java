package com.sample;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.sample.bean.Message;

public class Log4jDemo3 {
	static Logger log1 = null;

	public static void main(String args[]) {
		Message msg = new Message();
		msg.setMessage("Hello, This is Logging");
		System.out.println(msg.getMessage());
		log1 = Logger.getLogger(Log4jDemo3.class);
		PropertyConfigurator.configure("log4j1.properties");
		log1.debug("Debug Message");
		log1.info("Info Message");
		log1.warn("Warn Message");
		log1.error("Error Message");
		log1.fatal("Fatal Message");
	}
}
