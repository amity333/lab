package com.cg.mps.dao;

public interface QueryMapper {
	public static final String MOB_INSERT_QRY = "INSERT into purchasedetails(cname, mailid, phoneno, purchasedate, mobileid)Values(?,?,?,?,?)";
	public static final String MOB_SELECTALL = "SELECT * FROM mobiles";
	public static final String MOB_UPDATE = "UPDATE mobiles set quantity = (select quantity-1 from mobiles where mobileId = ?) where MobileId = ?";
	public static final String MOB_AVAIL = "SELECT quantity FROM mobileid";
	public static final String MOB_DEL_QRY = "DELETE FROM mobiles where mobileid = ?";
	public static final String MOB_SEL_BYRANGE = "SELECT * FROM mobiles WHERE price between ? AND ?";
}
