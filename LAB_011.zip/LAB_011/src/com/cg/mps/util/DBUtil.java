package com.cg.mps.util;

import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class DBUtil {
	static String unm;
	static String pwd;
	static String url;
	static String driver;

	public static Connection getCon() throws IOException, ClassNotFoundException, SQLException {
		// adding EmployeeException and add try and catch block
		Connection con = null;
		Properties dbProps = getDBInfo();
		unm = dbProps.getProperty("dbUserName");
		pwd = dbProps.getProperty("dbPassword");
		url = dbProps.getProperty("dbUrl");
		driver = dbProps.getProperty("dbDriver");
		Class.forName(driver);
		con = DriverManager.getConnection(url, unm, pwd);
		// catch(Exception ee)
		// {
		// throw new EmployeeException(ee.getMessage());
		// }
		return con;
	}

	public static Properties getDBInfo() throws IOException {
		FileReader fr = new FileReader("dbInfo.properties");
		Properties myProps = new Properties();
		myProps.load(fr);
		fr.close();
		return myProps;
	}
}
