package com.cg.mps.ui;

import java.io.IOException;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.mps.dto.Customer;
import com.cg.mps.service.MobilePurchaseService;
import com.cg.mps.service.MobilePurchaseServiceImpl;

public class MobilePurchase {
	static Logger log = Logger.getLogger(MobilePurchase.class);
	static Scanner sc = new Scanner(System.in);
	static MobilePurchaseService mps = null;

	public static void main(String[] args) {
		PropertyConfigurator.configure("log4j3.properties");
		mps = new MobilePurchaseServiceImpl();
		int choice = 0;
		while (true) {
			System.out.println("What is it that you desire?");
			System.out.println("1. Add Mobile Purchase");
			System.out.println("2. View All Mobiles Available in shop");
			System.out.println("3. Delete Mobile Details");
			System.out.println("4. Search Mobile Based on Price Range");
			System.out.println("5. Exit");
			choice = sc.nextInt();
			switch (choice) {
			case 1:
				addPurchase();
				break;
			case 2:
				viewAllMobiles();
				break;
			case 3:
				deleteMobile();
				break;
			case 4:
				searchBasedOnRange();
				break;
			case 5:
				System.exit(1);
				break;
			default:
				System.out.println("Wrong Choice, Enter Again");
				break;
			}
		}
	}

	private static void searchBasedOnRange() {
		System.out.println("Enter the Starting Price");
		float sPrice = sc.nextFloat();
		float ePrice = sc.nextFloat();
		try {
			ArrayList<Customer> list = mps.fetchByRange(sPrice, ePrice);
			System.out.println("These are the Mobiles Available");
			for (Customer c : list) {
				System.out.println("Mobile Id: " + c.getMobileId());
				System.out.println("Mobile Name: " + c.getMobileName());
				System.out.println("Mobile Price: " + c.getMobilePrice());
				System.out.println("Mobile Quantity Available: " + c.getMobileQuantity());
				System.out.println("");
			}
			log.info("Search Range" + sPrice + " " + ePrice);
		} catch (ClassNotFoundException | IOException | SQLException e) {
			// TODO Auto-generated catch block
			log.fatal(e.getMessage());
			e.printStackTrace();
		}
	}

	private static void deleteMobile() {
		System.out.println("Enter the Mobile Id that you want to delete");
		int MobileId = sc.nextInt();
		int count;
		try {
			count = mps.deleteMobileEmtries(MobileId);
			System.out.println(count + " Entry Deleted");
			log.info("Mobile Deleted");
		} catch (ClassNotFoundException | IOException | SQLException e) {
			// TODO Auto-generated catch block
			log.fatal(e.getMessage());
			e.printStackTrace();
		}
	}

	private static void viewAllMobiles() {
		ArrayList<Customer> list = new ArrayList<Customer>();
		try {
			list = mps.fetchAll();
			for (Customer c : list) {
				System.out.println("Mobile Details");
				System.out.println("Mobile Id: " + c.getMobileId());
				System.out.println("Mobile Name: " + c.getMobileName());
				System.out.println("Mobile Price: " + c.getMobilePrice());
				System.out.println("Mobile Quantity Available: " + c.getMobileQuantity());
				System.out.println("");
			}
		} catch (ClassNotFoundException | IOException | SQLException e) {
			// TODO Auto-generated catch block
			log.fatal(e.getMessage());
			e.printStackTrace();
		}
	}

	private static void addPurchase() {
		mps = new MobilePurchaseServiceImpl();
		System.out.println("Enter The Customer Name: ");
		String cName = sc.next();
		if (mps.validateName(cName)) {
			System.out.println("Enter the EmailId");
			String cEmail = sc.next();
			if (mps.validateMail(cEmail)) {
				System.out.println("Enter the Phone Number");
				long cPhone = Long.parseLong(sc.next());
				if (mps.validatePhone(cPhone)) {
					LocalDate date1 = LocalDate.now();
					System.out.println("Enter the Mobile Id");
					int mId = sc.nextInt();
					try {
						if (mps.Availability(mId)) {
							Customer c1 = new Customer(cName, cEmail, cPhone, date1, mId);
							try {
								int i = mps.addCust(c1);
								mps.updateQuantity(mId);
								log.info("Data Inserted");
								System.out.println(i + "customer added");
							} catch (ClassNotFoundException | IOException | SQLException e) {
								e.printStackTrace();
							}
						}
					} catch (ClassNotFoundException | IOException | SQLException e) {
						log.fatal(e.getMessage());
						e.printStackTrace();
					}
				}
			}
		}
	}
}
