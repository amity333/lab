package com.cg.mps.dto;

import java.time.LocalDate;

public class Customer {
	private int mobileId;
	private String mobileName;
	private float mobilePrice;
	private int mobileQuantity;
	private int purchaseId;
	private String custName;
	private String MailId;
	private long phoneNo;
	private LocalDate date;

	public Customer() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Customer(String custName, String mailId, long phoneNo, LocalDate date, int mobileId) {
		super();
		this.mobileId = mobileId;
		this.custName = custName;
		MailId = mailId;
		this.phoneNo = phoneNo;
		this.date = date;
	}

	public Customer(int mobileId, String mobileName, float mobilePrice, int mobileQuantity) {
		super();
		this.mobileId = mobileId;
		this.mobileName = mobileName;
		this.mobilePrice = mobilePrice;
		this.mobileQuantity = mobileQuantity;
	}

	public int getMobileId() {
		return mobileId;
	}

	public void setMobileId(int mobileId) {
		this.mobileId = mobileId;
	}

	public String getMobileName() {
		return mobileName;
	}

	public void setMobileName(String mobileName) {
		this.mobileName = mobileName;
	}

	public float getMobilePrice() {
		return mobilePrice;
	}

	public void setMobilePrice(float mobilePrice) {
		this.mobilePrice = mobilePrice;
	}

	public int getMobileQuantity() {
		return mobileQuantity;
	}

	public void setMobileQuantity(int mobileQuantity) {
		this.mobileQuantity = mobileQuantity;
	}

	public int getPurchaseId() {
		return purchaseId;
	}

	public void setPurchaseId(int purchaseId) {
		this.purchaseId = purchaseId;
	}

	public String getCustName() {
		return custName;
	}

	public void setCustName(String custName) {
		this.custName = custName;
	}

	public String getMailId() {
		return MailId;
	}

	public void setMailId(String mailId) {
		MailId = mailId;
	}

	public long getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(long phoneNo) {
		this.phoneNo = phoneNo;
	}

	public LocalDate getDate() {
		return date;
	}

	public void setDate(LocalDate date) {
		this.date = date;
	}

	@Override
	public String toString() {
		return "Customer [mobileId=" + mobileId + ", mobileName=" + mobileName + ", mobilePrice=" + mobilePrice
				+ ", mobileQuantity=" + mobileQuantity + ", purchaseId=" + purchaseId + ", custName=" + custName
				+ ", MailId=" + MailId + ", phoneNo=" + phoneNo + ", date=" + date + "]";
	}
}
