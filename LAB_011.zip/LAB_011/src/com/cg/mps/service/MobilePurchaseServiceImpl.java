package com.cg.mps.service;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.regex.Pattern;

import com.cg.mps.dao.MobileDao;
import com.cg.mps.dao.MobileDaoImpl;
import com.cg.mps.dto.Customer;

public class MobilePurchaseServiceImpl implements MobilePurchaseService {
	MobileDao mobileDao = new MobileDaoImpl();

	@Override
	public int addCust(Customer cust) throws ClassNotFoundException, IOException, SQLException {
		return mobileDao.addCust(cust);
	}

	@Override
	public int updateQuantity(int MobileId) throws ClassNotFoundException, IOException, SQLException {
		return mobileDao.updateQuantity(MobileId);
	}

	@Override
	public int deleteMobileEmtries(int MobileId) throws ClassNotFoundException, IOException, SQLException {
		return mobileDao.deleteMobileEmtries(MobileId);
	}

	@Override
	public ArrayList<Customer> fetchAll() throws ClassNotFoundException, IOException, SQLException {
		return mobileDao.fetchAll();
	}

	@Override
	public ArrayList<Customer> fetchByRange(float sRange, float eRange)
			throws ClassNotFoundException, IOException, SQLException {
		return mobileDao.fetchByRange(sRange, eRange);
	}

	@Override
	public boolean Availability(int mobileId) throws ClassNotFoundException, IOException, SQLException {
		return mobileDao.Availability(mobileId);
	}

	public boolean validatePhone(long PhoneNo) {
		String phone = new Long(PhoneNo).toString();
		String regex = "[789]{1}[0-9]{9}";
		if (Pattern.matches(regex, phone)) {
			return true;
		}
		return false;
	}

	public boolean validateMail(String cMail) {
		String cMailData = cMail;
		String regex = "^[A-Za-z0-9+._]+@(.+)$";
		if (Pattern.matches(regex, cMailData)) {
			return true;
		}
		return false;
	}

	public boolean validateName(String cName) {
		String cNameData = cName;
		String regex = "[A-Z][a-z]{1,19}";
		if (Pattern.matches(regex, cNameData)) {
			return true;
		}
		return false;
	}
}
