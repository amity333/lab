package com.cg.mps.dao;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

import com.cg.mps.dto.Customer;

public interface MobileDao {
	public int addCust(Customer cust) throws ClassNotFoundException, IOException, SQLException;

	public boolean Availability(int mobileId) throws ClassNotFoundException, IOException, SQLException;

	public int updateQuantity(int MobileId) throws ClassNotFoundException, IOException, SQLException;

	public int deleteMobileEmtries(int MobileId) throws ClassNotFoundException, IOException, SQLException;

	public ArrayList<Customer> fetchAll() throws ClassNotFoundException, IOException, SQLException;

	public ArrayList<Customer> fetchByRange(float sRange, float eRange)
			throws ClassNotFoundException, IOException, SQLException;
}
