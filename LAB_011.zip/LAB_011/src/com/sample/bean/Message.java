package com.sample.bean;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

public class Message {
	Logger log = null;
	private String msg;

	public void setMessage(String msg) {
		log = Logger.getLogger(Message.class);
		PropertyConfigurator.configure("log4j1.properties");
		log.debug("Debug Message");
		log.info("Info Message");
		log.warn("Warn Message");
		log.error("Error Message");
		log.fatal("Fatal Message");
		this.msg = msg;
	}

	public String getMessage() {
		log = Logger.getLogger(Message.class);
		PropertyConfigurator.configure("log4j1.properties");
		log.debug("Debug Message");
		log.info("Info Message");
		log.warn("Warn Message");
		log.error("Error Message");
		log.fatal("Fatal Message");
		return msg;
	}
}
